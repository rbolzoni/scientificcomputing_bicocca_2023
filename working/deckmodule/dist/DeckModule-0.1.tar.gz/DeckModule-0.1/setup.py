from setuptools import setup, find_packages

setup(name='DeckModule',
      description='deck and card class for the scientific computing course',
      author='Riccardo Bolzoni',
      author_email='r.bolzoni2@campus.unimib.it',
      version='0.1',
      packages=find_packages(),
      install_requires=[])